
// Esta función se ejecutará al cargar la página
function setName() {
	// Obtener el nombre de la URL
	const urlParams = new URLSearchParams(window.location.search);
	const name = urlParams.get('nombre_cliente');

	// Insertar el nombre en el HTML
	if (name) {
		document.getElementById('nombre_cliente').textContent = name;
	} else {
		document.getElementById('nombre_cliente').textContent = "invitado"; // Nombre por defecto
	}
}